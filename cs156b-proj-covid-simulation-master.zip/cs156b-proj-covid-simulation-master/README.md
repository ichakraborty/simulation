## Team COVID SIMulation Prediction Project

This repository contains various models to predict flu cases given the date, masking policy, adherence level, and population. The notebooks in the repository have models trained on policies including masking, protecting the elderly, and work from home, in addition to a tangential model trained on the H1N1 pandemic to see the effect of masking on a more contagious respiratory illness. 

The datasets beginning with Ox are from the Oxford policy tracker, those beginning with ILL, StateData, and WHO are flu cases from various sources, including the CDC and WHO, and the dataset beginning with nst is US Census data from 2010, which was used to determine state and US population levels.

